<?php
$DanhBa = [];

function ThemDanhBa($HoTen, $SoDienThoai, $Email)
{
    global $DanhBa;
    $ThongTin = [
        "HoTen" => $HoTen,
        "SoDienThoai" => $SoDienThoai,
        "Email" => $Email
    ];
    $DanhBa[] = $ThongTin;
}
function hienThiDanhBa()
{
    global $DanhBa;
    echo "<table border='1' style='margin-top: 20px'>
        <tr>
            <th>Ho ten</th>
            <th>So dien thoai</th>
            <th>Email</th>
        </tr>";

    foreach ($DanhBa as $key => $value) {
        echo "<tr>
            <td>{$value['HoTen']}</td>
            <td>{$value['SoDienThoai']}</td>
            <td>{$value['Email']}</td>
          </tr>";
    }

    echo "</table>";
}

function timKiemThongTin($danhBa, $hoTen)
{
    $timThay = false;
    foreach ($danhBa as $key => $value) {
        if ($hoTen == $value['HoTen']) {
            $timThay = true;
            echo "<h2>Đã tìm thấy thông tin của: $hoTen</h2>";
            echo "<table border='1'>
                    <tr>
                        <th>Ho ten</th>
                        <th>So dien thoai</th>
                        <th>Email</th>
                    </tr>
                    <tr>
                        <td>{$value['HoTen']}</td>
                        <td>{$value['SoDienThoai']}</td>
                        <td>{$value['Email']}</td>
                    </tr>
                  </table>";
            break;
        }
    }

    if (!$timThay) {
        echo "Không tìm thấy thông tin của $hoTen";
    }
}

ThemDanhBa("Nguyen Van A", "0123456789", "x0YQv@example.com");
ThemDanhBa("Nguyen Van B", "0987654321", "y0YQv@example.com");
ThemDanhBa("Nguyen Van C", "0123498765", "z0YQv@example.com");
// ThemDanhBa("Nguyen Van D", "0987651234", "J0YQv@example.com");

hienThiDanhBa();


?>

<form action="" method="post" style="margin-top: 10px;">
    <input type="text" name="HoTen" placeholder="Ho ten">
    <button name="search" value="search">Tim kiem</button>
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['search'])) {
    if (isset($_POST['HoTen']) && $_POST['HoTen'] != '') {
        $HoTen = $_POST['HoTen'];
        timKiemThongTin($DanhBa, $HoTen);
    }
}
?>